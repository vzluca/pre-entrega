**Generador de chistes**

**Trigger:** Schedule Trigger – se ejecuta cada 1 hora automáticamente.

**Nodos:**
- GET Chiste: llama a api.chucknorris.io y trae un chiste aleatorio en JSON.
- Normalizar Datos: extrae el texto, el ID y el largo del chiste con un nodo Set.
- IF Corto o Largo: evalúa si el chiste tiene menos de 100 caracteres.
- Email chiste corto: envía un email si el chiste es corto (rama TRUE).
- Email chiste largo: envía un email si el chiste es largo (rama FALSE).

**Condicional:** se evalúa el largo del texto porque permite clasificar el chiste sin metadata adicional.

**Notificación:** Gmail con OAuth2. La credencial queda almacenada solo en n8n, no en el JSON exportado.